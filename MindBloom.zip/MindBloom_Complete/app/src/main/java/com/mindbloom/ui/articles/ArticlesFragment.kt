package com.mindbloom.ui.articles

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.mindbloom.data.model.Article
import com.mindbloom.data.model.ArticleCategory
import com.mindbloom.databinding.FragmentArticlesBinding

class ArticlesFragment : Fragment() {

    private var _binding: FragmentArticlesBinding? = null
    private val binding get() = _binding!!

    private val allArticles = listOf(
        Article(1, "5 Proven Techniques to Manage Exam Stress",
            "Learn breathing exercises, time management and mindful breaks to reduce exam anxiety.",
            "Dr. Sarah Mitchell", ArticleCategory.STRESS, 5),
        Article(2, "Why 8 Hours of Sleep Is Non-Negotiable for Students",
            "Sleep deprivation affects memory consolidation, concentration and emotional regulation.",
            "Prof. Rahul Sharma", ArticleCategory.SLEEP, 7),
        Article(3, "10-Minute Mindfulness Routine for Busy Students",
            "A simple morning mindfulness practice that fits into any schedule.",
            "Dr. Priya Patel", ArticleCategory.MINDFULNESS, 4),
        Article(4, "Understanding Exam Anxiety: Causes and Solutions",
            "Anxiety before exams is normal, but when it becomes overwhelming it needs attention.",
            "Dr. Ananya Singh", ArticleCategory.ANXIETY, 6),
        Article(5, "Foods That Naturally Reduce Stress and Anxiety",
            "Your diet has a profound impact on your mood, energy and stress resilience.",
            "Nutritionist Meera Kapoor", ArticleCategory.NUTRITION, 5),
        Article(6, "How to Build a Healthy Sleep Schedule Around Classes",
            "Practical strategies for aligning your sleep with your academic timetable.",
            "Dr. Vikram Nair", ArticleCategory.SLEEP, 6),
        Article(7, "Progressive Muscle Relaxation for Stress Relief",
            "A step-by-step guide to releasing physical tension caused by academic pressure.",
            "Dr. Sarah Mitchell", ArticleCategory.STRESS, 4)
    )

    private lateinit var adapter: ArticleAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentArticlesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupChipFilters()
    }

    private fun setupRecyclerView() {
        adapter = ArticleAdapter(allArticles)
        binding.rvArticles.layoutManager = LinearLayoutManager(requireContext())
        binding.rvArticles.adapter = adapter
    }

    private fun setupChipFilters() {
        binding.chipGroupCategories.setOnCheckedStateChangeListener { _, checkedIds ->
            val filtered = when (checkedIds.firstOrNull()) {
                binding.chipStress.id      -> allArticles.filter { it.category == ArticleCategory.STRESS }
                binding.chipSleep.id       -> allArticles.filter { it.category == ArticleCategory.SLEEP }
                binding.chipMindfulness.id -> allArticles.filter { it.category == ArticleCategory.MINDFULNESS }
                binding.chipAnxiety.id     -> allArticles.filter { it.category == ArticleCategory.ANXIETY }
                binding.chipNutrition.id   -> allArticles.filter { it.category == ArticleCategory.NUTRITION }
                else                       -> allArticles
            }
            adapter.updateList(filtered)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
