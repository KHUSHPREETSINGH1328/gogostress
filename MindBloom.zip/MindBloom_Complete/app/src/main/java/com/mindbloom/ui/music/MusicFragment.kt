package com.mindbloom.ui.music

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.mindbloom.data.model.Playlist
import com.mindbloom.data.model.PlaylistCategory
import com.mindbloom.databinding.FragmentMusicBinding

class MusicFragment : Fragment() {

    private var _binding: FragmentMusicBinding? = null
    private val binding get() = _binding!!
    private var isPlaying = false

    private val playlists = listOf(
        Playlist(1, "Focus & Study", "📚", 12, 45, PlaylistCategory.FOCUS, 0),
        Playlist(2, "Deep Relaxation", "🌊", 8, 32, PlaylistCategory.RELAXATION, 0),
        Playlist(3, "Sleep Sounds", "🌙", 10, 60, PlaylistCategory.SLEEP, 0),
        Playlist(4, "Nature & Ambient", "🌿", 15, 55, PlaylistCategory.NATURE, 0),
        Playlist(5, "Meditation", "🧘", 6, 28, PlaylistCategory.MEDITATION, 0)
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMusicBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupPlayButton()
    }

    private fun setupRecyclerView() {
        binding.rvPlaylists.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlaylists.adapter = PlaylistAdapter(playlists) { playlist ->
            binding.tvSongName.text = playlist.name
            binding.tvSongCategory.text = "${playlist.category.name} • ${playlist.durationMinutes} min"
            Toast.makeText(requireContext(), "Playing: ${playlist.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupPlayButton() {
        binding.fabPlayPause.setOnClickListener {
            isPlaying = !isPlaying
            binding.fabPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
