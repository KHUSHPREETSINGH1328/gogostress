package com.mindbloom.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.mindbloom.databinding.FragmentHomeBinding
import java.util.Calendar

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setGreeting()
        setupMoodButtons()
    }

    private fun setGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        binding.tvGreeting.text = when {
            hour < 12 -> "Good Morning"
            hour < 17 -> "Good Afternoon"
            else      -> "Good Evening"
        }
    }

    private fun setupMoodButtons() {
        val moods = listOf(
            binding.btnMoodGreat to "Great 😄",
            binding.btnMoodGood  to "Good 🙂",
            binding.btnMoodOkay  to "Okay 😐",
            binding.btnMoodBad   to "Not Great 😔",
            binding.btnMoodTerrible to "Feeling down 😢"
        )
        moods.forEach { (btn, label) ->
            btn.setOnClickListener {
                Toast.makeText(requireContext(), "Mood logged: $label", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
