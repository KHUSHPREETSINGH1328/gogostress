package com.mindbloom.data.model

// ─── Music ────────────────────────────────────────────────────────────────────

data class Playlist(
    val id: Int,
    val name: String,
    val emoji: String,
    val trackCount: Int,
    val durationMinutes: Int,
    val category: PlaylistCategory,
    val backgroundColor: Int
)

enum class PlaylistCategory {
    FOCUS, RELAXATION, SLEEP, NATURE, MEDITATION
}

data class Track(
    val id: Int,
    val title: String,
    val artist: String,
    val durationSeconds: Int,
    val playlistId: Int,
    val emoji: String = "🎵"
) {
    val formattedDuration: String
        get() {
            val minutes = durationSeconds / 60
            val seconds = durationSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}

// ─── Diet ─────────────────────────────────────────────────────────────────────

data class Meal(
    val id: Int,
    val type: MealType,
    val name: String,
    val calories: Int,
    val emoji: String,
    val time: String,
    val items: List<String>
)

enum class MealType(val label: String, val emoji: String) {
    BREAKFAST("Breakfast", "🌅"),
    LUNCH("Lunch", "☀️"),
    DINNER("Dinner", "🌙"),
    SNACK("Snack", "🍎")
}

data class StressFood(
    val name: String,
    val emoji: String,
    val benefit: String,
    val category: String
)

// ─── Articles ─────────────────────────────────────────────────────────────────

data class Article(
    val id: Int,
    val title: String,
    val excerpt: String,
    val author: String,
    val category: ArticleCategory,
    val readTimeMinutes: Int,
    val content: String = ""
)

enum class ArticleCategory(val label: String) {
    ALL("All"),
    STRESS("Stress"),
    SLEEP("Sleep"),
    MINDFULNESS("Mindfulness"),
    ANXIETY("Anxiety"),
    NUTRITION("Nutrition")
}

// ─── Timetable ────────────────────────────────────────────────────────────────

data class SleepRoutineItem(
    val id: Int,
    val time: String,
    val name: String,
    val description: String,
    val emoji: String,
    var isEnabled: Boolean = true
)

data class SleepGoal(
    val bedtime: String,
    val wakeTime: String,
    val goalHours: Int = 8
)

data class SleepTip(
    val emoji: String,
    val title: String,
    val description: String
)

// ─── Mood ─────────────────────────────────────────────────────────────────────

enum class MoodType(val emoji: String, val label: String) {
    GREAT("😄", "Great"),
    GOOD("🙂", "Good"),
    OKAY("😐", "Okay"),
    BAD("😔", "Not Great"),
    TERRIBLE("😢", "Terrible")
}

data class DailyStats(
    val stressLevel: String,
    val sleepHours: Float,
    val streakDays: Int,
    val selectedMood: MoodType? = null
)
