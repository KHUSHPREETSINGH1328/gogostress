package com.mindbloom.ui.articles

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.mindbloom.data.model.Article
import com.mindbloom.databinding.ItemArticleBinding

class ArticleAdapter(private var articles: List<Article>) :
    RecyclerView.Adapter<ArticleAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(article: Article) {
            binding.tvArticleTitle.text = article.title
            binding.tvArticleExcerpt.text = article.excerpt
            binding.tvArticleAuthor.text = article.author
            binding.tvArticleCategory.text = article.category.label
            binding.tvReadTime.text = "${article.readTimeMinutes} min read"
            binding.btnReadMore.setOnClickListener {
                Toast.makeText(binding.root.context,
                    "Opening: ${article.title}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun updateList(newList: List<Article>) {
        articles = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemArticleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(articles[position])

    override fun getItemCount() = articles.size
}
