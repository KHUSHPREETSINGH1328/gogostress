package com.mindbloom.ui.diet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.mindbloom.data.model.Meal
import com.mindbloom.data.model.MealType
import com.mindbloom.databinding.FragmentDietBinding

class DietFragment : Fragment() {

    private var _binding: FragmentDietBinding? = null
    private val binding get() = _binding!!
    private var waterCount = 5

    private val meals = listOf(
        Meal(1, MealType.BREAKFAST, "Oats with Banana", 350, "🥣", "8:00 AM",
            listOf("Oatmeal", "Banana", "Honey", "Milk")),
        Meal(2, MealType.LUNCH, "Grilled Chicken Salad", 490, "🥗", "1:00 PM",
            listOf("Chicken breast", "Lettuce", "Tomato", "Olive oil")),
        Meal(3, MealType.SNACK, "Mixed Nuts", 180, "🥜", "4:00 PM",
            listOf("Almonds", "Walnuts", "Cashews")),
        Meal(4, MealType.DINNER, "Dal Rice", 400, "🍛", "8:00 PM",
            listOf("Dal", "Rice", "Vegetables", "Ghee"))
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDietBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupWaterButton()
        updateWaterDisplay()
        binding.btnAddMeal.setOnClickListener {
            Toast.makeText(requireContext(), "Meal logging coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        binding.rvMeals.layoutManager = LinearLayoutManager(requireContext())
        binding.rvMeals.adapter = MealAdapter(meals)
    }

    private fun setupWaterButton() {
        binding.btnAddWater.setOnClickListener {
            if (waterCount < 12) {
                waterCount++
                updateWaterDisplay()
            } else {
                Toast.makeText(requireContext(), "Great job staying hydrated! 💧", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateWaterDisplay() {
        binding.tvWaterCount.text = "$waterCount / 8"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
