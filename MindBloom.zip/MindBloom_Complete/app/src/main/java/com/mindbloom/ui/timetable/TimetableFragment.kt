package com.mindbloom.ui.timetable

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.mindbloom.data.model.SleepRoutineItem
import com.mindbloom.databinding.FragmentTimetableBinding
import java.util.Calendar

class TimetableFragment : Fragment() {

    private var _binding: FragmentTimetableBinding? = null
    private val binding get() = _binding!!

    private val routines = mutableListOf(
        SleepRoutineItem(1, "9:00 PM", "Stop screen time",
            "Put away phone and laptop", "📵", true),
        SleepRoutineItem(2, "9:30 PM", "Light stretching / yoga",
            "10 minutes of gentle stretching", "🧘", true),
        SleepRoutineItem(3, "9:45 PM", "Warm shower",
            "Helps lower core body temperature", "🚿", true),
        SleepRoutineItem(4, "10:00 PM", "Read a book",
            "Avoid screens — use a physical book", "📚", false),
        SleepRoutineItem(5, "10:15 PM", "Journaling",
            "Write 3 things you are grateful for", "📓", true),
        SleepRoutineItem(6, "10:30 PM", "Lights out",
            "Keep room cool and dark", "🌙", true)
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTimetableBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupTimeButtons()
        setupAddRoutine()
    }

    private fun setupRecyclerView() {
        binding.rvRoutines.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRoutines.adapter = RoutineAdapter(routines) { item, isEnabled ->
            item.isEnabled = isEnabled
        }
    }

    private fun setupTimeButtons() {
        binding.btnSetBedtime.setOnClickListener {
            showTimePicker("Bedtime") { time -> binding.tvBedtime.text = time }
        }
        binding.btnSetWakeTime.setOnClickListener {
            showTimePicker("Wake Time") { time -> binding.tvWakeTime.text = time }
        }
    }

    private fun setupAddRoutine() {
        binding.btnAddRoutine.setOnClickListener {
            Toast.makeText(requireContext(), "Add custom routine coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showTimePicker(title: String, onTimeSet: (String) -> Unit) {
        val cal = Calendar.getInstance()
        TimePickerDialog(requireContext(), { _, hour, minute ->
            val amPm = if (hour < 12) "AM" else "PM"
            val displayHour = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            onTimeSet("%d:%02d %s".format(displayHour, minute, amPm))
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).apply {
            setTitle(title)
            show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
