package com.mindbloom.ui.timetable

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mindbloom.data.model.SleepRoutineItem
import com.mindbloom.databinding.ItemRoutineBinding

class RoutineAdapter(
    private val routines: List<SleepRoutineItem>,
    private val onToggle: (SleepRoutineItem, Boolean) -> Unit
) : RecyclerView.Adapter<RoutineAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemRoutineBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: SleepRoutineItem) {
            binding.tvRoutineTime.text = item.time
            binding.tvRoutineEmoji.text = item.emoji
            binding.tvRoutineName.text = item.name
            binding.tvRoutineDescription.text = item.description
            binding.switchRoutine.isChecked = item.isEnabled
            binding.switchRoutine.setOnCheckedChangeListener { _, checked ->
                onToggle(item, checked)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemRoutineBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(routines[position])

    override fun getItemCount() = routines.size
}
