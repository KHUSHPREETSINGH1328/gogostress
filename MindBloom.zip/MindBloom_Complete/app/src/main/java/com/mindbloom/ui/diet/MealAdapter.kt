package com.mindbloom.ui.diet

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mindbloom.data.model.Meal
import com.mindbloom.databinding.ItemPlaylistBinding

class MealAdapter(private val meals: List<Meal>) :
    RecyclerView.Adapter<MealAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemPlaylistBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(meal: Meal) {
            binding.tvPlaylistName.text = "${meal.type.label}: ${meal.name}"
            binding.tvPlaylistEmoji.text = meal.emoji
            binding.tvPlaylistTrackCount.text = "${meal.calories} kcal • ${meal.time}"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(meals[position])

    override fun getItemCount() = meals.size
}
